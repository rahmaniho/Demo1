import { useEffect, useRef, useState } from "react";

/* ------------------------------------------------------------------ *
 *  Northlight Windows — single-page clone
 *  Dark, editorial, nature-inspired window & roof-window company.
 * ------------------------------------------------------------------ */

type NavLink = { label: string; href: string };

const NAV: NavLink[] = [
  { label: "Windows", href: "#windows" },
  { label: "Comfort", href: "#comfort" },
  { label: "Projects", href: "#projects" },
  { label: "Process", href: "#process" },
  { label: "About", href: "#about" },
  { label: "FAQ", href: "#faq" },
];

type Solution = {
  n: string;
  title: string;
  text: string;
  points: string[];
  image: string;
};

const SOLUTIONS: Solution[] = [
  {
    n: "01",
    title: "Window Replacement",
    text: "Retrofit or full-frame replacement of tired, drafty or fogged units, matched to the character of your home.",
    points: ["Full-frame & insert options", "Historic profile matching", "Interior trim restored"],
    image: "/images/sol-replacement.jpg",
  },
  {
    n: "02",
    title: "New Installation",
    text: "New openings, additions and remodels — framed, flashed and sealed for decades of weather.",
    points: ["Structural opening support", "Flashing & weather barrier", "Builder coordination"],
    image: "/images/belief.jpg",
  },
  {
    n: "03",
    title: "Energy-Efficient Upgrades",
    text: "Low-E coated, argon-filled glazing that keeps rooms warmer in winter and calmer in summer.",
    points: ["ENERGY STAR® certified units", "Double & triple pane", "Rebate paperwork handled"],
    image: "/images/sol-energy.jpg",
  },
  {
    n: "04",
    title: "Custom Window Styles",
    text: "Casement, picture, awning, bay and arched shapes, built to the exact size of each opening.",
    points: ["Wood, fiberglass & clad", "Custom shapes & grilles", "Hardware in brass or bronze"],
    image: "/images/proj-loft.jpg",
  },
];

const WHY = [
  {
    title: "Licensed & insured installers",
    text: "Our own trained crews — not subcontractors — handle every installation.",
  },
  {
    title: "Clear, written quotes",
    text: "Itemized pricing for product, labor and finishing, with no surprise line items.",
  },
  {
    title: "Respect for your home",
    text: "Floor protection, dust control and full clean-up are part of every job.",
  },
  {
    title: "Workmanship warranty",
    text: "Installation is backed by our written warranty alongside the manufacturer coverage.",
  },
];

type Project = { title: string; meta: string; image: string };

const PROJECTS: Project[] = [
  { title: "Forest Park Cabin", meta: "Roof windows · 6 units", image: "/images/proj-cabin.jpg" },
  { title: "Laurelhurst Craftsman", meta: "Full replacement · 22 units", image: "/images/proj-craftsman.jpg" },
  { title: "West Hills Residence", meta: "Lift & slide · 4 panels", image: "/images/proj-hills.jpg" },
  { title: "Sellwood Loft", meta: "Picture windows · 3 units", image: "/images/proj-loft.jpg" },
];

const STEPS = [
  {
    n: "01",
    title: "Consultation",
    text: "We visit your home, look at every opening and talk through styles, materials and budget.",
  },
  {
    n: "02",
    title: "Precise measuring",
    text: "Each opening is measured and documented so every window is ordered to the right size.",
  },
  {
    n: "03",
    title: "Ordering & scheduling",
    text: "You approve the final quote; we order your windows and book an installation date.",
  },
  {
    n: "04",
    title: "Clean installation",
    text: "Certified installers remove, fit, seal and finish — and leave the room as they found it.",
  },
];

const COMFORT = [
  {
    title: "Daylight",
    text: "Larger glass areas and slimmer frames let more light deeper into each room.",
  },
  {
    title: "Thermal comfort",
    text: "Insulated glazing reduces cold spots near windows and summer heat gain.",
  },
  {
    title: "Quiet",
    text: "Laminated acoustic glass softens traffic and neighborhood noise.",
  },
];

const FAQ = [
  {
    q: "How long does a window replacement project take?",
    a: "Most homes are installed in one to three days once windows arrive. Lead time for ordered windows is typically four to eight weeks depending on style and finish.",
  },
  {
    q: "Do I need to replace all my windows at once?",
    a: "No. Many homeowners start with the rooms that matter most and phase the rest. We will help you plan a sequence that keeps styles consistent.",
  },
  {
    q: "Will new windows lower my energy bills?",
    a: "Upgrading from single-pane or failing units usually reduces heat loss and drafts. Actual savings depend on your home, climate and the windows you choose.",
  },
  {
    q: "Do you handle permits and rebates?",
    a: "We take care of permit paperwork where required and handle ENERGY STAR rebate documentation so you receive the credits you qualify for.",
  },
  {
    q: "What window materials do you install?",
    a: "We work with wood, fiberglass and clad frames from a curated set of premium manufacturers, matched to the character of your home.",
  },
];

const FOOTER_COLUMNS = [
  {
    title: "Windows",
    links: [
      { label: "Solutions", href: "#windows" },
      { label: "Natural light", href: "#comfort" },
      { label: "Projects", href: "#projects" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "#about" },
      { label: "Our process", href: "#process" },
      { label: "FAQ", href: "#faq" },
    ],
  },
];

/* --------------------------- small helpers --------------------------- */

function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

/** Fade + rise into view when scrolled into the viewport. */
function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cx("reveal", visible && "is-visible", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-sage">
      <span className="h-px w-6 bg-sage/60" />
      {children}
    </span>
  );
}

/* ------------------------------ Nav bar ------------------------------ */

function NavBar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cx(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "border-b border-line/80 bg-ink/80 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <a href="#top" className="group flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-glow/40 bg-glow/10 text-glow transition-colors group-hover:bg-glow/20">
            <WindowIcon className="h-4 w-4" />
          </span>
          <span className="font-serif text-lg tracking-tight text-cream">
            Northlight
          </span>
        </a>

        <nav className="hidden items-center gap-9 md:flex">
          {NAV.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-cream-2/80 transition-colors hover:text-cream"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#estimate"
            className="hidden rounded-full bg-cream px-5 py-2 text-sm font-semibold text-ink transition-transform hover:-translate-y-0.5 sm:inline-flex"
          >
            Free estimate
          </a>
          <button
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-cream md:hidden"
          >
            <BurgerIcon open={open} />
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <div
        className={cx(
          "overflow-hidden border-t border-line/70 bg-ink/95 backdrop-blur-xl transition-[max-height] duration-500 md:hidden",
          open ? "max-h-96" : "max-h-0"
        )}
      >
        <nav className="flex flex-col gap-1 px-6 py-4">
          {NAV.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-2 py-3 text-cream-2/90 transition-colors hover:bg-ink-2 hover:text-cream"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#estimate"
            onClick={() => setOpen(false)}
            className="mt-2 rounded-full bg-cream px-5 py-3 text-center text-sm font-semibold text-ink"
          >
            Free estimate
          </a>
        </nav>
      </div>
    </header>
  );
}

/* --------------------- Interactive light window ---------------------- */

function LightWindow() {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 50, y: 38 });
  const [active, setActive] = useState(false);

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos({
      x: ((e.clientX - r.left) / r.width) * 100,
      y: ((e.clientY - r.top) / r.height) * 100,
    });
  };

  return (
    <div className="relative">
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseEnter={() => setActive(true)}
        onMouseLeave={() => setActive(false)}
        className="relative aspect-[4/5] w-full overflow-hidden rounded-[28px] border border-line bg-ink-2 shadow-2xl shadow-black/50 sm:aspect-[4/5]"
      >
        <img
          src="/images/hero.jpg"
          alt="Forest viewed through a contemporary window"
          className="absolute inset-0 h-full w-full object-cover"
        />
        {/* moving light bloom */}
        <div
          className="pointer-events-none absolute inset-0 transition-opacity duration-700"
          style={{
            opacity: active ? 1 : 0.55,
            background: `radial-gradient(420px circle at ${pos.x}% ${pos.y}%, rgba(231,199,154,0.45), rgba(231,199,154,0.12) 35%, transparent 60%)`,
          }}
        />
        {/* mullions / window frame */}
        <div className="pointer-events-none absolute inset-0 grid grid-cols-2 grid-rows-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="border border-cream/15" />
          ))}
        </div>
        <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-cream/10" />
        {/* floating sun orb */}
        <div
          className="animate-float-slow pointer-events-none absolute h-16 w-16 rounded-full bg-glow/70 blur-xl transition-all duration-500"
          style={{ left: `${pos.x}%`, top: `${pos.y}%`, transform: "translate(-50%,-50%)" }}
        />
        <span className="absolute bottom-4 left-4 rounded-full bg-ink/50 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-cream-2 backdrop-blur-sm">
          Move your light
        </span>
      </div>
      <div className="pointer-events-none absolute -bottom-6 -right-4 h-40 w-40 rounded-full bg-moss/30 blur-3xl" />
    </div>
  );
}

/* ------------------------------- Hero -------------------------------- */

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 lg:pt-36">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 pb-20 lg:grid-cols-2 lg:gap-16 lg:px-10 lg:pb-28">
        <Reveal className="order-2 lg:order-1">
          <SectionEyebrow>Natural light &amp; living comfort</SectionEyebrow>
          <h1 className="mt-6 font-serif text-[2.6rem] leading-[1.04] text-cream sm:text-6xl lg:text-[4.2rem]">
            Rooms that <span className="italic text-glow">follow the day.</span>
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-cream-2/80">
            Well-placed, well-sealed glass changes how a home feels: brighter
            mornings, quieter evenings, steadier temperatures and a constant,
            gentle connection to the trees outside.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#estimate"
              className="group inline-flex items-center gap-2 rounded-full bg-cream px-6 py-3 text-sm font-semibold text-ink transition-transform hover:-translate-y-0.5"
            >
              Get a free estimate
              <ArrowIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </a>
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 text-sm font-medium text-cream-2 transition-colors hover:border-glow/40 hover:text-cream"
            >
              See our work
            </a>
          </div>

          <div className="mt-12 grid max-w-md grid-cols-3 gap-px overflow-hidden rounded-2xl border border-line bg-line/40">
            {[
              ["20+", "Years installing"],
              ["4,800", "Windows fitted"],
              ["4.9★", "Homeowner rating"],
            ].map(([stat, label]) => (
              <div key={label} className="bg-ink px-4 py-5">
                <div className="font-serif text-2xl text-cream">{stat}</div>
                <div className="mt-1 text-xs text-muted">{label}</div>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal className="order-1 lg:order-2" delay={120}>
          <LightWindow />
        </Reveal>
      </div>

      {/* soft horizon glow */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-glow/30 to-transparent" />
    </section>
  );
}

/* ----------------------------- Belief -------------------------------- */

function Belief() {
  return (
    <section id="about" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 lg:grid-cols-2 lg:gap-16 lg:px-10">
        <Reveal>
          <div className="overflow-hidden rounded-3xl border border-line">
            <img
              src="/images/belief.jpg"
              alt="A craftsperson installing a window"
              className="aspect-[4/3] w-full object-cover"
            />
          </div>
        </Reveal>
        <Reveal delay={100}>
          <SectionEyebrow>Our belief</SectionEyebrow>
          <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
            A Better View Begins at Home.
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-cream-2/85">
            A window is the one part of a house you look through every day. We
            replace and install windows so the light, the trees and the seasons
            outside feel like part of the rooms you live in.
          </p>
          <p className="mt-4 leading-relaxed text-cream-2/70">
            Northlight is a residential window company. We survey, supply and
            install replacement and new-construction windows for homeowners who
            care about how a room feels at seven in the morning and at dusk in
            December.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            {["Replacement", "Roof windows", "New construction", "Custom shapes"].map(
              (t) => (
                <span
                  key={t}
                  className="rounded-full border border-line px-4 py-1.5 text-xs text-cream-2/80"
                >
                  {t}
                </span>
              )
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ----------------------------- Comfort ------------------------------- */

function Comfort() {
  return (
    <section id="comfort" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 lg:grid-cols-2 lg:gap-16 lg:px-10">
        <Reveal>
          <SectionEyebrow>Natural light &amp; living comfort</SectionEyebrow>
          <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
            A constant, gentle connection to the trees.
          </h2>
          <p className="mt-6 max-w-md leading-relaxed text-cream-2/75">
            We think about more than the unit in the wall. The right glass
            quietly reshapes the everyday — here is what changes.
          </p>
          <dl className="mt-10 space-y-7">
            {COMFORT.map((c, i) => (
              <div key={c.title} className="flex gap-5">
                <div className="font-serif text-2xl text-glow/80">
                  0{i + 1}
                </div>
                <div>
                  <dt className="font-serif text-xl text-cream">{c.title}</dt>
                  <dd className="mt-1 max-w-sm leading-relaxed text-cream-2/70">
                    {c.text}
                  </dd>
                </div>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative">
            <div className="overflow-hidden rounded-[28px] border border-line">
              <img
                src="/images/why.jpg"
                alt="A bright room with large windows overlooking trees"
                className="aspect-[4/5] w-full object-cover"
              />
            </div>
            <div className="pointer-events-none absolute -left-5 -top-5 h-32 w-32 rounded-full bg-glow/20 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-6 -right-4 h-40 w-40 rounded-full bg-moss/30 blur-3xl" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ----------------------------- Windows ------------------------------- */

function Windows() {
  return (
    <section id="windows" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal className="max-w-2xl">
          <SectionEyebrow>What we do</SectionEyebrow>
          <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
            Windows for every opening.
          </h2>
          <p className="mt-5 leading-relaxed text-cream-2/75">
            From a single fogged pane to a whole-home transformation, we match
            the right product and profile to the character of your house.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-px overflow-hidden rounded-3xl border border-line bg-line/40 md:grid-cols-2">
          {SOLUTIONS.map((s, i) => (
            <Reveal key={s.n} delay={i * 70} className="bg-ink">
              <article className="group flex h-full flex-col">
                <div className="relative overflow-hidden">
                  <img
                    src={s.image}
                    alt={s.title}
                    className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                  />
                  <span className="absolute left-4 top-4 rounded-full bg-ink/60 px-3 py-1 text-xs font-medium text-cream backdrop-blur-sm">
                    {s.n}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-7">
                  <h3 className="font-serif text-2xl text-cream">{s.title}</h3>
                  <p className="mt-3 leading-relaxed text-cream-2/75">{s.text}</p>
                  <ul className="mt-5 space-y-2.5">
                    {s.points.map((p) => (
                      <li key={p} className="flex items-start gap-2.5 text-sm text-cream-2/80">
                        <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-sage" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Why Northlight --------------------------- */

function Why() {
  return (
    <section className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16 lg:px-10">
        <Reveal>
          <div className="overflow-hidden rounded-3xl border border-line">
            <img
              src="/images/why.jpg"
              alt="A finished room with new windows"
              className="aspect-[4/3] w-full object-cover"
            />
          </div>
        </Reveal>
        <Reveal delay={100}>
          <SectionEyebrow>Why us</SectionEyebrow>
          <h2 className="mt-5 font-serif text-3xl leading-tight text-cream sm:text-4xl">
            Why homeowners choose Northlight windows
          </h2>
          <ul className="mt-9 space-y-px overflow-hidden rounded-2xl border border-line bg-line/30">
            {WHY.map((w) => (
              <li key={w.title} className="flex gap-4 bg-ink p-5">
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-sage/40 text-sage">
                  <CheckIcon className="h-4 w-4" />
                </span>
                <div>
                  <h3 className="text-base font-semibold text-cream">{w.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-cream-2/70">
                    {w.text}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}

/* ----------------------------- Projects ------------------------------ */

function Projects() {
  return (
    <section id="projects" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-xl">
            <SectionEyebrow>Recent work</SectionEyebrow>
            <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
              Projects we are proud of.
            </h2>
          </div>
          <p className="max-w-sm leading-relaxed text-cream-2/70">
            A few homes around the Pacific Northwest where new light changed
            how the rooms are lived in.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {PROJECTS.map((p, i) => (
            <Reveal key={p.title} delay={i * 70}>
              <article className="group overflow-hidden rounded-2xl border border-line bg-ink-2">
                <div className="relative overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.title}
                    className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent" />
                </div>
                <div className="p-5">
                  <h3 className="font-serif text-xl text-cream">{p.title}</h3>
                  <p className="mt-1 text-sm text-sage">{p.meta}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- Process ------------------------------- */

function Process() {
  return (
    <section id="process" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 lg:grid-cols-2 lg:gap-16 lg:px-10">
        <Reveal className="order-2 lg:order-1">
          <div className="overflow-hidden rounded-3xl border border-line">
            <img
              src="/images/hero.jpg"
              alt="A clean window installation"
              className="aspect-[4/3] w-full object-cover"
            />
          </div>
        </Reveal>
        <Reveal delay={100} className="order-1 lg:order-2">
          <SectionEyebrow>How it works</SectionEyebrow>
          <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
            From survey to installation.
          </h2>
          <div className="mt-10 space-y-7">
            {STEPS.map((s) => (
              <div key={s.n} className="flex gap-5">
                <div className="font-serif text-3xl text-glow/70">{s.n}</div>
                <div className="border-l border-line pl-5">
                  <h3 className="font-serif text-xl text-cream">{s.title}</h3>
                  <p className="mt-1 leading-relaxed text-cream-2/70">{s.text}</p>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------------------- FAQ --------------------------------- */

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16 lg:px-10">
        <Reveal>
          <SectionEyebrow>FAQ</SectionEyebrow>
          <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
            Questions, answered.
          </h2>
          <p className="mt-5 max-w-sm leading-relaxed text-cream-2/70">
            Still unsure about something? Tell us about your home and a designer
            will reply within one business day.
          </p>
          <a
            href="#estimate"
            className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-glow"
          >
            Ask us anything <ArrowIcon className="h-4 w-4" />
          </a>
        </Reveal>

        <Reveal delay={100} className="space-y-3">
          {FAQ.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={item.q}
                className="overflow-hidden rounded-2xl border border-line bg-ink-2"
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-serif text-lg text-cream">{item.q}</span>
                  <span
                    className={cx(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-line text-cream-2 transition-transform duration-300",
                      isOpen && "rotate-45 border-glow/50 text-glow"
                    )}
                  >
                    <PlusIcon />
                  </span>
                </button>
                <div
                  className={cx(
                    "grid transition-all duration-500 ease-out",
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  )}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-6 leading-relaxed text-cream-2/75">
                      {item.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}

/* ----------------------------- Estimate ------------------------------ */

function Estimate() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="estimate" className="relative border-t border-line/60 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="overflow-hidden rounded-[32px] border border-line bg-gradient-to-b from-ink-2 to-ink">
          <div className="grid lg:grid-cols-2">
            <Reveal className="p-8 lg:p-14">
              <SectionEyebrow>Free estimate</SectionEyebrow>
              <h2 className="mt-5 font-serif text-4xl leading-tight text-cream sm:text-5xl">
                Let’s frame your next view.
              </h2>
              <p className="mt-5 max-w-md leading-relaxed text-cream-2/75">
                Tell us a little about your home. A designer will reply within
                one business day with next steps and a visit time.
              </p>

              {sent ? (
                <div className="mt-9 rounded-2xl border border-sage/40 bg-sage/10 p-6">
                  <div className="flex items-center gap-3 text-sage">
                    <CheckIcon className="h-5 w-5" />
                    <span className="font-medium">Thanks — we’ll be in touch shortly.</span>
                  </div>
                  <p className="mt-2 text-sm text-cream-2/75">
                    A Northlight designer will reach out within one business day.
                  </p>
                </div>
              ) : (
                <form onSubmit={onSubmit} className="mt-9 space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Name" placeholder="Jane Porter" required />
                    <Field label="Email" type="email" placeholder="you@example.com" required />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Phone" placeholder="Optional" />
                    <Field label="ZIP" placeholder="97210" />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm text-cream-2/80">
                      Project details
                    </label>
                    <textarea
                      rows={3}
                      placeholder="How many windows, and anything we should know?"
                      className="w-full resize-none rounded-xl border border-line bg-ink px-4 py-3 text-sm text-cream placeholder:text-faint focus:border-glow/50 focus:outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-cream px-6 py-3.5 text-sm font-semibold text-ink transition-transform hover:-translate-y-0.5 sm:w-auto"
                  >
                    Request my estimate
                    <ArrowIcon className="h-4 w-4" />
                  </button>
                </form>
              )}
            </Reveal>

            <Reveal delay={120} className="relative">
              <img
                src="/images/estimate.jpg"
                alt="A design consultation at a kitchen table by a sunny window"
                className="h-full min-h-[320px] w-full object-cover lg:min-h-full"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/40 via-transparent to-transparent lg:bg-gradient-to-l" />
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  placeholder,
  type = "text",
  required,
}: {
  label: string;
  placeholder?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm text-cream-2/80">
        {label}
        {required && <span className="text-glow"> *</span>}
      </label>
      <input
        type={type}
        required={required}
        placeholder={placeholder}
        className="w-full rounded-xl border border-line bg-ink px-4 py-3 text-sm text-cream placeholder:text-faint focus:border-glow/50 focus:outline-none"
      />
    </div>
  );
}

/* ------------------------------ Footer ------------------------------- */

function Footer() {
  return (
    <footer className="relative border-t border-line/60 pt-16">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid gap-12 pb-14 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full border border-glow/40 bg-glow/10 text-glow">
                <WindowIcon className="h-4 w-4" />
              </span>
              <span className="font-serif text-lg text-cream">Northlight</span>
            </a>
            <p className="mt-5 max-w-xs leading-relaxed text-cream-2/70">
              Better windows, quietly installed — so the light, the trees and
              the seasons feel like part of home.
            </p>
          </div>

          {FOOTER_COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((l) => (
                  <li key={l.href + l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-cream-2/80 transition-colors hover:text-cream"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">
              Visit
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-cream-2/80">
              <li>2140 NW Thurman St, Portland, OR 97210</li>
              <li>
                <a href="tel:+15035550148" className="transition-colors hover:text-cream">
                  (503) 555-0148
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@northlightwindows.com"
                  className="transition-colors hover:text-cream"
                >
                  hello@northlightwindows.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-start justify-between gap-4 border-t border-line/60 py-7 text-sm text-faint sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} Northlight Windows. All rights reserved.</p>
          <p className="text-cream-2/50">Residential windows — replacement &amp; installation</p>
        </div>
      </div>
    </footer>
  );
}

/* ------------------------------ Icons -------------------------------- */

function WindowIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M12 4v16M3 12h18" />
    </svg>
  );
}

function ArrowIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

function CheckIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

function PlusIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function BurgerIcon({ open }: { open: boolean }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" className="h-5 w-5">
      {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
    </svg>
  );
}

/* ------------------------------- App --------------------------------- */

export default function App() {
  return (
    <div className="page-grain relative">
      <NavBar />
      <main className="relative z-10">
        <Hero />
        <Belief />
        <Comfort />
        <Windows />
        <Why />
        <Projects />
        <Process />
        <Faq />
        <Estimate />
      </main>
      <Footer />
    </div>
  );
}
